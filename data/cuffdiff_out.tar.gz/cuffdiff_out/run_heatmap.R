#heatmap
#Install heatmap.2 packages
install.packages("gplots")
library(gplots)

y#read in files
setwd("~/Desktop/ch4_demo_dataset/cuffdiff_out/")

#load file with selected loci, based of p value
allde = read.table("", sep = "\t", header=TRUE, row.names=1)

##Remove rows with missing values
allde541 = na.omit(allde541)

##Plot heatmap
allde541_matrix <- data.matrix(allde541)
colors <- colorRampPalette(c("yellow", "orange", "red"))(n = 299)
col_breaks = c(seq(0,100,length=100), seq(100,200,length=100), seq(200,300,length=100))
png(filename = "75N_fpkm.png", width = 700, height = 1000, units = "px", pointsize = 15)
heatmap541 <- heatmap.2(allde541_matrix, col=colors, na.rm=TRUE, labRow = NULL, breaks=col_breaks, symbreaks=FALSE, dendrogram="row", Colv="NA", key=TRUE, symkey=FALSE, density.info="none", trace="none", margins=c(10,10), cexCol=1)
dev.off()